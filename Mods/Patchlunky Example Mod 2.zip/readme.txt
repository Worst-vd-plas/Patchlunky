The dog damsel is changed into a caveman.

This mod is a zip archive named "Patchlunky Example Mod 2.zip" inside the Patchlunky Mods directory. Patchlunky can load zip archives directly, as long as the file structure inside the zip is correct.

This mod also makes use of the XML mod format and LUA script support present in Patchlunky 1.0.0.2.
