Patchlunky Example Mod #2
-------
The dog damsel is changed into a caveman.

This mod is a zip archive named "Patchlunky Example Mod 2.zip" inside the Patchlunky Mods directory.

Patchlunky can load zip archives directly, as long as the file structure inside the zip is correct.