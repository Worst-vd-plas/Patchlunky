-- Lua Patch script for Patchlunky Example Mod 2

-- Load the journalmons image from alltex.wad
local jmons = image.load("alltex.wad:ATSTART/journalmons.png")

-- Load the caveman images included in this mod
local cman = image.load("Textures/caveman.png")
local cmanhead = image.load("Textures/caveman_head.png")

-- Draw the caveman replacing the portion of the image that has the dog
jmons:draw_image(cman, 1920, 384, image.MODE_REPLACE)

-- Draw the caveman head on top the dog head that is next to other damsel heads
jmons:draw_image(cmanhead, 1723, 445, image.MODE_OVERLAY)

-- Save the journalmons image, now that we are done changing it.
jmons:save("alltex.wad:ATSTART/journalmons.png")


-- Load the monstersbig3 image from alltex.wad
local monbig3 = image.load("alltex.wad:MONSTERS/monstersbig3.png")

-- Load the caveman spritesheets from this mod
local cman_basic = image.load("Textures/caveman_basic.png")
local cman_worship = image.load("Textures/caveman_worship.png")

-- Draw the caveman spritesheets replacing portions of the monstersbig3 image
monbig3:draw_image(cman_basic, 160, 0, image.MODE_REPLACE)
monbig3:draw_image(cman_worship, 0, 800, image.MODE_REPLACE)

-- Save the monstersbig3 image back to alltex.wad
monbig3:save("alltex.wad:MONSTERS/monstersbig3.png")

